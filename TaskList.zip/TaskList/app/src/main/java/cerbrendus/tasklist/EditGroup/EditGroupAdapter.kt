package cerbrendus.tasklist.EditGroup

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.ColorRes
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import cerbrendus.tasklist.BaseClasses.AttributeColor
import cerbrendus.tasklist.BaseClasses.AttributeColorViewHolder
import cerbrendus.tasklist.BaseClasses.BaseAttribute
import cerbrendus.tasklist.BaseClasses.EditAdapter
import cerbrendus.tasklist.R
import kotlin.coroutines.experimental.coroutineContext

class EditGroupAdapter(
    _context: FragmentActivity) : EditAdapter(_context){

    override val vm = EditGroupViewModel.create(context)

    override fun makeAttributeList(): List<BaseAttribute> = listOf(AttributeColor(R.color.colorAccent))
}