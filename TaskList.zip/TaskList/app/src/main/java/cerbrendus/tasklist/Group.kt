package cerbrendus.tasklist

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "group_list")
data class Group(@PrimaryKey(autoGenerate = true) var id :Long? = null,
                 var title : String,
                 var visibleInMain : Boolean =  true) {

}