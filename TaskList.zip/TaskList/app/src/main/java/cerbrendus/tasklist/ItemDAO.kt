package cerbrendus.tasklist


import androidx.lifecycle.LiveData
import androidx.room.*

//Created by Brendan on 29-12-2018.
@Dao
interface ItemDAO {
    @Insert
    fun insertItems(vararg items: TaskItem)
    @Update
    fun updateItems(vararg items: TaskItem)
    @Delete
    fun deleteItems(vararg items: TaskItem)
    @Query("SELECT * FROM main_item_list")
    fun getAllItems(): LiveData<List<TaskItem>>
}