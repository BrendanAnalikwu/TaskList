package cerbrendus.tasklist

import android.app.Application
import androidx.lifecycle.LiveData
import org.jetbrains.anko.doAsync

//Created by Brendan on 30-12-2018.
class ItemRepository(application: Application) {
    private val itemDB = ItemDatabase.getInstance(application)!!
    private val itemDAO = itemDB.itemDAO()
    private val allItems: LiveData<List<TaskItem>> = itemDAO.getAllItems()

    fun getAll() = allItems

    fun insert(item: TaskItem) {
        doAsync {
            itemDAO.insertItems(item)
        }
    }

    fun update(item: TaskItem) {
        doAsync {
            itemDAO.updateItems(item)
        }
    }

    fun delete(item: TaskItem) {
        doAsync {
            itemDAO.deleteItems(item)
        }
    }
}