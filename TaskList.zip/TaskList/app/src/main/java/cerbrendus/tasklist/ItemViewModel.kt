package cerbrendus.tasklist

import android.app.Application
import androidx.appcompat.view.menu.MenuView
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModelProviders

//Created by Brendan on 30-12-2018.
class ItemViewModel(application: Application) : AndroidViewModel(application) {
    private val itemRepo = ItemRepository(application)
    private val allItems: LiveData<List<TaskItem>> = itemRepo.getAll()

    fun insert(item: TaskItem) {itemRepo.insert(item)}
    fun update(item: TaskItem) {itemRepo.update(item)}
    fun delete(item: TaskItem) {itemRepo.delete(item)}
    fun getAll() = allItems

    var editType : MutableLiveData<Int> = MutableLiveData()
    var ETAOpenedAsView = false

    init {
        editType.value = TYPE_ADD
    }

    companion object {
        private var vm: ItemViewModel? = null
        fun create(activity: FragmentActivity):ItemViewModel =
            if(vm===null) ViewModelProviders.of(activity).get(ItemViewModel::class.java)
            else vm!!
    }
}