package cerbrendus.tasklist

import android.content.Intent
import android.content.res.Resources
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.lifecycle.Observer
import androidx.appcompat.app.ActionBar
import androidx.recyclerview.widget.DividerItemDecoration
import com.wangjie.rapidfloatingactionbutton.RapidFloatingActionHelper
import com.wangjie.rapidfloatingactionbutton.contentimpl.labellist.RFACLabelItem
import com.wangjie.rapidfloatingactionbutton.contentimpl.labellist.RapidFloatingActionContentLabelList
import com.wangjie.rapidfloatingactionbutton.contentimpl.labellist.RapidFloatingActionContentLabelList.OnRapidFloatingActionContentLabelListListener
import com.wangjie.rapidfloatingactionbutton.RapidFloatingActionButton
import com.wangjie.rapidfloatingactionbutton.RapidFloatingActionLayout



fun Int.toPx() : Int = (this / Resources.getSystem().displayMetrics.density).toInt()

class MainActivity : AppCompatActivity(), OnRapidFloatingActionContentLabelListListener<MainActivity> {
    var rfabHelper : RapidFloatingActionHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //Get ViewModel
        val vm = ItemViewModel.create(this)

        //Setup Toolbar
        setSupportActionBar(findViewById(R.id.toolbar_main_activity))

        //Get UI handles for RFAB
        val rfaLayout: RapidFloatingActionLayout = findViewById(R.id.activity_main_rfal)
        val rfaBtn: RapidFloatingActionButton = findViewById(R.id.rfab_add)

        //Get RecyclerView handle
        val recyclerView: RecyclerView = findViewById(R.id.main_recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        val itemDecor = DividerItemDecoration(this, (recyclerView.layoutManager as LinearLayoutManager).orientation)
        recyclerView.addItemDecoration(itemDecor)

        //Set RecyclerView adapters
        val adapter = ItemAdapter(vm.getAll().value.orEmpty(),this.applicationContext)
        recyclerView.adapter = adapter
            //update list content
        vm.getAll().observe(this, Observer<List<TaskItem>> { newList: List<TaskItem> -> adapter.setItems(newList)})

        //RapidFloatingActionButton setup
        val rfaContent = RapidFloatingActionContentLabelList(this)
        rfaContent.setOnRapidFloatingActionContentLabelListListener(this)
        val items = mutableListOf<RFACLabelItem<Int>>(
            RFACLabelItem<Int>()
                .setLabel("new Task")
                .setResId(R.mipmap.ic_launcher_round)
                .setIconNormalColor(0xffd84315.toInt())
                .setWrapper(0),
            RFACLabelItem<Int>()
                .setLabel("new Workflow")
                .setResId(R.mipmap.ic_launcher_round)
                .setIconNormalColor(0xffd8a515.toInt())
                .setWrapper(1)
            )
        rfaContent.items = items.toList()
        rfaContent.setIconShadowColor(0xff888888.toInt())
            .setIconShadowDx(5.toPx())
            .setIconShadowDy(5.toPx())
        rfabHelper = RapidFloatingActionHelper(this,rfaLayout,rfaBtn,rfaContent).build()
    }

    override fun onRFACItemIconClick(position: Int, item: RFACLabelItem<MainActivity>?) {
        rfabHelper!!.toggleContent()
        when(position){
            0 -> openEditTaskActivity(TYPE_ADD)
        }
    }

    override fun onRFACItemLabelClick(position: Int, item: RFACLabelItem<MainActivity>?) {
        rfabHelper!!.toggleContent()
        when(position){
            0 -> openEditTaskActivity(TYPE_ADD)
        }
    }

    private fun openEditTaskActivity(type: Int) {
        val vm = ItemViewModel.create(this)

        val intent = Intent(this,EditTaskActivity::class.java).apply {
            putExtra(TYPE_INTENT_KEY,type)
        }
        vm.editType.value = type
        startActivity(intent)
    }


}
