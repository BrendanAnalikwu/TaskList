package cerbrendus.tasklist

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

//Created by Brendan on 29-12-2018.
@Parcelize
@Entity(tableName = "main_item_list")
data class TaskItem(var title: String,
                    @PrimaryKey(autoGenerate = true) var id :Long? = null,
                    var description: String? = null,
                    var group_id: Int? = null,
                    var link_id: Int? = null,
                    var visible: Boolean=true,
                    var pending: Boolean=false) : Parcelable {
}